# Usage

Simply just click the [link]() and you will open diagrams.net and be able to use the latest icons. If you want to use this in draw.io desktop client. Then use the following link for import.

https://raw.githubusercontent.com/mauriciolauffer/sap_btp_icons_drawio_lib/main/libs/SAP_BTP_Service_Icons_latest.xml